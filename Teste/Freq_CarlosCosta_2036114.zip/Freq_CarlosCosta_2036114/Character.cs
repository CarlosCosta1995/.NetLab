﻿namespace Freq_CarlosCosta_2036114
{
    public class Character
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Homeworld { get; set; }
        public string Born { get; set; }
        public bool Jedi { get; set; }

    }
}