﻿namespace Freq_CarlosCosta_2036114
{
    public class Charactersl
    {
        public List<Character> Characters { get; set; }

        public Charactersl()
        {
            Characters = new List<Character>();
        }
    }
}
