using Freq_CarlosCosta_2036114;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

//Instancia da class CharacterList
Charactersl charactersJson = LoadCharacterListFromJson();

Charactersl LoadCharacterListFromJson()
{
    string deserializejson = File.ReadAllText("characters.json");
    Charactersl listofCharacters = JsonSerializer.Deserialize<Charactersl>(deserializejson);
    return listofCharacters;
}

app.MapGet("/characters", () =>
{
    if (charactersJson == null)
    {
        return Results.NotFound("Json File is Empty.");
    }
    else
    {
        return Results.Ok(charactersJson);
    }
});

app.MapPost("/characters", (Character cha) =>
{
    if (charactersJson.Characters.Count == 0)
    {
        cha.Id = 1;
        charactersJson.Characters.Add(cha);
    }
    else
    {
        var lasCharacter = charactersJson.Characters.LastOrDefault();
        cha.Id = lasCharacter.Id + 1;
        charactersJson.Characters.Add(cha);
    }
    return Results.Created("characters.json", cha);
});


app.MapDelete("/characters/{Id:int}", (int id) =>
{
    int removed = charactersJson.Characters.RemoveAll(user => user.Id == id);
    if (removed == 0)
    {
        return Results.NotFound($"A user with the id:{id} was not found.");
    }
    else
    {
        return Results.Ok($"A character with {id} has been removed.");
    } 
});


app.MapGet("/characters/characterId/{Id:int}", (int id) =>
{
    Character characterFounded = charactersJson.Characters.Find(user => user.Id == id);
    if (characterFounded == null)
    {
        return Results.NotFound($"A user with the id:{id} was not found.");
    }
    else
    {
        return Results.Ok(characterFounded);
    }
});

app.MapPut("/characters/{Id:int}", (int id, Character Charater) =>
{
    Character characterFounded = charactersJson.Characters.Find(user => user.Id == id);
    if (characterFounded == null)
    {
        return Results.NotFound($"A user with the id:{id} was not found.");
    }
    else
    {
        characterFounded.Name = characterFounded.Name;
        characterFounded.Gender = Charater.Gender;
        characterFounded.Homeworld = Charater.Homeworld;
        characterFounded.Born = Charater.Born;
        characterFounded.Jedi = Charater.Jedi;
        return Results.Ok(characterFounded);
    }
});

app.MapGet("/characters/characterGender/{gender}", (string gender) =>
{
    List<Character> listCharactersFound = charactersJson.Characters.FindAll(user => user.Gender == gender);
    if (listCharactersFound == null)
    {
        return Results.NotFound($"A user with the id:{gender} was not found.");
    }
    else
    {
        return Results.Ok(listCharactersFound);
    }
});

app.MapGet("/characters/characterJedi/{jedi}", (bool jedi) =>
{
    List<Character> listCharactersFound = charactersJson.Characters.FindAll(user => user.Jedi == jedi);
    if (listCharactersFound == null)
    {
        return Results.NotFound($"A user with the id:{jedi} was not found.");
    }
    else
    {
        return Results.Ok(listCharactersFound);
    }
});

app.MapGet("/characters/download", () =>
{ 
    string serializeJson = JsonSerializer.Serialize(charactersJson);
    File.WriteAllText("charactersUpdated.json", serializeJson);

    try 
    {
        byte[] Bytes = File.ReadAllBytes(serializeJson);
        return Results.File(Bytes, null, "charactersUpdated.json");
    }
    catch (FileNotFoundException e)
    {
        return Results.NotFound(e.Message);
    }
});

app.Run();
